const mongoose = require('mongoose')

mongoose.connect('mongodb://127.0.0.1:27017/friday')

const urlSchema = {
    _id: {
        type: mongoose.SchemaTypes.ObjectId
    },
    ogLink: {
        type: String,
        required: true
    },
    shortLink: {
        type: String,
        required: true,
        unique: true
    },
    visit: {
        type: Number,
        default: 0
    },
}
const short = mongoose.model('urlshortener', urlSchema) 

module.exports = short;