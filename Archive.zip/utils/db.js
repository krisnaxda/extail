


// //tambah data
// const link = new urlShort({
//     ogLink: 'https://www.instagram.com',
//     shortLink: 'er2F8',
//     visit: '0' 
// })


// //simpan ke collection
// link.save().then((urlShort) => console.log(urlShort))